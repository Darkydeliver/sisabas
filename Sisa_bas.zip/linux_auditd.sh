#!/bin/bash

# Install auditd if not installed
if ! command -v auditd &> /dev/null
then
    echo "auditd not found, installing..."
    sudo apt update
    sudo apt install -y auditd audispd-plugins
fi

# Start and enable auditd
sudo systemctl start auditd
sudo systemctl enable auditd

# Download audit rules
cd /etc/audit/rules.d
sudo rm -f audit.rules  # Use -f to avoid error if file does not exist

echo "Downloading audit rules..."
sudo wget -q https://raw.githubusercontent.com/Neo23x0/auditd/master/audit.rules -O audit.rules

# Define the new audit rules
AUDIT_RULE64="-a always,exit -F arch=b64 -S execve -k all_commands"
AUDIT_RULE32="-a always,exit -F arch=b32 -S execve -k all_commands"

# Insert rules above # Self Auditing
echo "Inserting custom audit rules..."
sudo sed -i "/# Self Auditing/i $AUDIT_RULE64\n$AUDIT_RULE32" /etc/audit/rules.d/audit.rules

# Restart auditd to apply the rules
sudo systemctl restart auditd

echo "Auditd setup complete. All command executions will be logged to /var/log/audit/audit.log."
